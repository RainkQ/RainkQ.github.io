LumoGrain LUT collection. Source and colour contracts: catalog.json. Official Fujifilm: F-Log2C -> BT.709 gamma 2.4. Other files: sRGB -> sRGB. Third-party fits are not manufacturer implementations.
